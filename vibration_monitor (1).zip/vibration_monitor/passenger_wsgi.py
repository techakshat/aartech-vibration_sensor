#import os
#import sys


#sys.path.insert(0, os.path.dirname(__file__))


#def application(environ, start_response):
#  start_response('200 OK', [('Content-Type', 'text/plain')])
#    message = 'It works!\n'
#    version = 'Python %s\n' % sys.version.split()[0]
#    response = '\n'.join([message, version])
#    return [response.encode()]

# from vibration_monitor.wsgi import application

import sys
import os

sys.path.insert(0, '/home/j2ejsg6i7ya2/vibration_monitor')
sys.path.insert(1, '/home/j2ejsg6i7ya2/vibration_monitor/vibration_monitor')

os.environ['DJANGO_SETTINGS_MODULE'] = 'vibration_monitor.settings'

from django.core.wsgi import get_wsgi_application
application = get_wsgi_application()
