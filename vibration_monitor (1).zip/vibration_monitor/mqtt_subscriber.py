import os
import django
import json
import sys
import paho.mqtt.client as mqtt
from django.utils import timezone

# === Django Setup ===
sys.path.append(os.path.dirname(os.path.abspath(__file__)))
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "vibration_monitor.settings")
django.setup()

from vibration.models import VibrationData  # Import your model after setup

# === MQTT Config ===
MQTT_BROKER = "broker.emqx.io"   # Public broker (for local test)
MQTT_PORT = 1883
MQTT_TOPIC = "vibration/data"

# === Callbacks ===
def on_connect(client, userdata, flags, rc):
    print("[✓] MQTT connected")
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    try:
        payload = json.loads(msg.payload.decode())
        VibrationData.objects.create(
            timestamp=timezone.now(),
            acceleration_x=payload.get("acceleration_x", 0),
            acceleration_y=payload.get("acceleration_y", 0),
            acceleration_z=payload.get("acceleration_z", 0),
        )
        print(f"[→] Data saved: {payload}")
    except Exception as e:
        print(f"[✗] Error saving to DB: {e}")

def start_subscriber():
    try:
        client = mqtt.Client()
        client.on_connect = on_connect
        client.on_message = on_message
        client.connect(MQTT_BROKER, MQTT_PORT, 60)
        print(f"[...] Subscribing to {MQTT_TOPIC} on {MQTT_BROKER}:{MQTT_PORT}")
        client.loop_forever()
    except Exception as e:
        print(f"[✗] MQTT error: {e}")

if __name__ == "__main__":
    start_subscriber()
