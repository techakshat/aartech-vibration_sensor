from django.urls import path
from .views import dashboard # vibration_data_view
from .views import download_csv


urlpatterns = [
    path('', dashboard, name='dashboard'),
    path('download_csv/', download_csv, name='download_csv'),
    # path('vibration_data_view/', vibration_data_view, name='vibration_data'),
]
from django.urls import path
from . import views
from .views import login_view, show_data, save_data, get_data
from .views import receive_data

urlpatterns = [
    path('', views.home, name="home"),  # Home page
    path('login/', login_view, name="login"),  # Login page
    path('about/', views.about, name="about"),
    path('contact/', views.contact, name="contact"),
    path('vibration_data/', show_data, name="vibration_data"),  # Data display page
    path('save_data/', save_data, name="save_data"),
    path('get_data/', get_data, name="get_data"),
    path('download_csv/', views.download_csv, name='download_csv'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('get_realtime_data/', views.get_realtime_data, name='get_realtime_data'),
    path('get_fft_data/', views.get_fft_data, name='get_fft_data'),
    path('get_rms_values/', views.get_rms_values, name= 'get_rms_values'),
    path('receive-data/', receive_data, name='receive_data'),
]


