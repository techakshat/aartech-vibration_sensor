from django.shortcuts import render, redirect
from django.http import JsonResponse, HttpResponse
from django.views.decorators.csrf import csrf_exempt
import json
import csv
from .models import VibrationData
import os
os.environ["OPENBLAS_NUM_THREADS"] = "1" 
import numpy as np
from scipy.fft import fft
import math

@csrf_exempt
def home(request):
    return render(request, "home.html")

@csrf_exempt
def about(request):
    return render(request, "about.html")

@csrf_exempt
def contact(request):
    return render(request, "contact.html")

@csrf_exempt
def save_data(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            VibrationData.objects.create(x=data['x'], y=data['y'], z=data['z'])
            return JsonResponse({"message": "Data saved"}, status=201)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Invalid request"}, status=400)

def show_data(request):
    data = VibrationData.objects.order_by('-timestamp')[:50]
    return render(request, "vibration_data.html", {"data": data})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if username == "ad" and password == "123":
            return redirect("vibration_data")
        return render(request, "login.html", {"error": "Invalid username or password"})
    return render(request, "login.html")

@csrf_exempt
def get_data(request):
    data = VibrationData.objects.order_by('-timestamp')[:10]
    return render(request, "vibration_data.html", {"data": data})

def download_csv(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="vibration_data.csv"'
    writer = csv.writer(response)
    writer.writerow(['Timestamp', 'Acceleration X', 'Acceleration Y', 'Acceleration Z'])
    vibration_data = VibrationData.objects.all()
    for entry in vibration_data:
        writer.writerow([entry.timestamp, entry.acceleration_x, entry.acceleration_y, entry.acceleration_z])
    return response

def dashboard(request):
    return render(request, "dashboard.html")

@csrf_exempt
def get_realtime_data(request):
    data = VibrationData.objects.order_by('-timestamp')[:400][::-2]
    response_data = [{
        "timestamp": entry.timestamp,
        "x": entry.acceleration_x,
        "y": entry.acceleration_y,
        "z": entry.acceleration_z
    } for entry in data]
    return JsonResponse(response_data, safe=False)

def get_fft_data(request):
    window_size = 20
    sampling_rate = 10
    time_step = 1 / sampling_rate
    data = VibrationData.objects.order_by('-timestamp')[:window_size]
    data = list(reversed(data))
    if len(data) < window_size:
        return JsonResponse({"error": f"Insufficient data. Need {window_size} samples, got {len(data)}"}, status=400)
    x_signal = np.array([entry.acceleration_x for entry in data])
    y_signal = np.array([entry.acceleration_y for entry in data])
    z_signal = np.array([entry.acceleration_z for entry in data])
    fft_x = fft(x_signal)
    fft_y = fft(y_signal)
    fft_z = fft(z_signal)
    half_n = window_size // 2
    freqs = np.fft.fftfreq(window_size, d=time_step)[:half_n]
    response_data = {
        "frequencies": freqs.tolist(),
        "fft_x": np.abs(fft_x[:half_n]).tolist(),
        "fft_y": np.abs(fft_y[:half_n]).tolist(),
        "fft_z": np.abs(fft_z[:half_n]).tolist(),
        "metadata": {
            "sampling_rate": sampling_rate,
            "window_size": window_size,
            "units": "m/s²"
        }
    }
    return JsonResponse(response_data)

def calculate_rms(data):
    return math.sqrt(sum(x**2 for x in data) / len(data))

def get_rms_values(request):
    data = VibrationData.objects.order_by('-timestamp')[:10][::-1]
    x_values = np.array([entry.x for entry in data])
    y_values = np.array([entry.y for entry in data])
    z_values = np.array([entry.z for entry in data])
    rms_x = calculate_rms(x_values)
    rms_y = calculate_rms(y_values)
    rms_z = calculate_rms(z_values)
    response_data = {
        "rms_x": rms_x,
        "rms_y": rms_y,
        "rms_z": rms_z
    }
    return JsonResponse(response_data)

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import VibrationData  # if you have this model

@csrf_exempt
def receive_data(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            x = data.get('x')
            y = data.get('y')
            z = data.get('z')

            # Save to DB using correct field names
            VibrationData.objects.create(
                acceleration_x=x,
                acceleration_y=y,
                acceleration_z=z
            )

            return JsonResponse({'status': 'success', 'received': data})
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=400)

    return JsonResponse({'error': 'Only POST allowed'}, status=405)

